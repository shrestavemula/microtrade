import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import Alpaca from '@alpacahq/alpaca-trade-api';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());

// ── Alpaca Client ───────────────────────────────────────────
const alpaca = new Alpaca({
  keyId: process.env.ALPACA_API_KEY,
  secretKey: process.env.ALPACA_SECRET_KEY,
  paper: process.env.ALPACA_PAPER === 'true',
});

const isPaper = process.env.ALPACA_PAPER === 'true';

// ── Health / Status ─────────────────────────────────────────
app.get('/api/status', async (req, res) => {
  try {
    const clock = await alpaca.getClock();
    res.json({
      connected: true,
      paper: isPaper,
      marketOpen: clock.is_open,
      nextOpen: clock.next_open,
      nextClose: clock.next_close,
    });
  } catch (err) {
    res.json({ connected: false, paper: isPaper, error: err.message });
  }
});

// ── Account ─────────────────────────────────────────────────
app.get('/api/account', async (req, res) => {
  try {
    const account = await alpaca.getAccount();
    res.json({
      id: account.id,
      cash: parseFloat(account.cash),
      portfolioValue: parseFloat(account.portfolio_value),
      equity: parseFloat(account.equity),
      buyingPower: parseFloat(account.buying_power),
      daytradeCount: account.daytrade_count,
      patternDayTrader: account.pattern_day_trader,
      tradingBlocked: account.trading_blocked,
      transfersBlocked: account.transfers_blocked,
      currency: account.currency,
      status: account.status,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Positions ───────────────────────────────────────────────
app.get('/api/positions', async (req, res) => {
  try {
    const positions = await alpaca.getPositions();
    res.json(positions.map(p => ({
      symbol: p.symbol,
      qty: parseFloat(p.qty),
      avgEntry: parseFloat(p.avg_entry_price),
      currentPrice: parseFloat(p.current_price),
      marketValue: parseFloat(p.market_value),
      unrealizedPL: parseFloat(p.unrealized_pl),
      unrealizedPLPC: parseFloat(p.unrealized_plpc),
      side: p.side,
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Orders ──────────────────────────────────────────────────
app.get('/api/orders', async (req, res) => {
  try {
    const orders = await alpaca.getOrders({ status: 'all', limit: 50 });
    res.json(orders.map(o => ({
      id: o.id,
      symbol: o.symbol,
      qty: parseFloat(o.qty || o.notional),
      filledQty: parseFloat(o.filled_qty),
      type: o.type,
      side: o.side,
      status: o.status,
      filledAvgPrice: o.filled_avg_price ? parseFloat(o.filled_avg_price) : null,
      submittedAt: o.submitted_at,
      filledAt: o.filled_at,
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Place Order ─────────────────────────────────────────────
app.post('/api/orders', async (req, res) => {
  try {
    const { symbol, qty, side, type = 'market', timeInForce = 'day', notional } = req.body;

    // Safety: block trades over $100 for this micro-trading app
    if (notional && parseFloat(notional) > 100) {
      return res.status(400).json({ error: 'MicroTrade limits orders to $100. Reduce your order size.' });
    }

    const orderParams = {
      symbol: symbol.toUpperCase(),
      side, // 'buy' or 'sell'
      type,
      time_in_force: timeInForce,
    };

    // Support both fractional (notional $) and share qty
    if (notional) {
      orderParams.notional = parseFloat(notional).toFixed(2);
    } else {
      orderParams.qty = parseFloat(qty);
    }

    const order = await alpaca.createOrder(orderParams);

    res.json({
      id: order.id,
      symbol: order.symbol,
      side: order.side,
      type: order.type,
      qty: order.qty,
      notional: order.notional,
      status: order.status,
      submittedAt: order.submitted_at,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ── Cancel Order ────────────────────────────────────────────
app.delete('/api/orders/:id', async (req, res) => {
  try {
    await alpaca.cancelOrder(req.params.id);
    res.json({ cancelled: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ── Market Data: Quote ──────────────────────────────────────
app.get('/api/quote/:symbol', async (req, res) => {
  try {
    const quote = await alpaca.getLatestQuote(req.params.symbol.toUpperCase());
    const trade = await alpaca.getLatestTrade(req.params.symbol.toUpperCase());
    res.json({
      symbol: req.params.symbol.toUpperCase(),
      price: trade.Price,
      bidPrice: quote.BidPrice,
      askPrice: quote.AskPrice,
      bidSize: quote.BidSize,
      askSize: quote.AskSize,
      timestamp: trade.Timestamp,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Market Data: Bars (chart data) ──────────────────────────
app.get('/api/bars/:symbol', async (req, res) => {
  try {
    const { timeframe = '1Min', start, end, limit = 200 } = req.query;
    const symbol = req.params.symbol.toUpperCase();

    const bars = await alpaca.getBars(timeframe, symbol, {
      start: start || new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      end: end || new Date().toISOString(),
      limit: parseInt(limit),
    });

    const data = (bars[symbol] || []).map(b => ({
      time: new Date(b.Timestamp).getTime() / 1000,
      open: b.OpenPrice,
      high: b.HighPrice,
      low: b.LowPrice,
      close: b.ClosePrice,
      volume: b.Volume,
    }));

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Market Data: Snapshot (multiple stocks) ─────────────────
app.get('/api/snapshots', async (req, res) => {
  try {
    const symbols = (req.query.symbols || '').split(',').filter(Boolean);
    if (!symbols.length) return res.json({});

    const snapshots = await alpaca.getSnapshots(symbols);
    const result = {};

    for (const [sym, snap] of Object.entries(snapshots)) {
      result[sym] = {
        price: snap.LatestTrade?.Price || 0,
        prevClose: snap.PrevDailyBar?.ClosePrice || 0,
        open: snap.DailyBar?.OpenPrice || 0,
        high: snap.DailyBar?.HighPrice || 0,
        low: snap.DailyBar?.LowPrice || 0,
        close: snap.DailyBar?.ClosePrice || 0,
        volume: snap.DailyBar?.Volume || 0,
      };
    }

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── News ────────────────────────────────────────────────────
app.get('/api/news', async (req, res) => {
  try {
    const { symbols = '', limit = 20 } = req.query;
    const news = await alpaca.getNews({
      symbols: symbols || undefined,
      limit: parseInt(limit),
    });

    res.json(news.map(n => ({
      id: n.id,
      headline: n.headline,
      summary: n.summary,
      source: n.source,
      url: n.url,
      symbols: n.symbols,
      createdAt: n.created_at,
      updatedAt: n.updated_at,
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Asset Search ────────────────────────────────────────────
app.get('/api/assets/search', async (req, res) => {
  try {
    const { q } = req.query;
    const assets = await alpaca.getAssets({ status: 'active' });
    const matches = assets
      .filter(a => a.tradable && a.fractionable &&
        (a.symbol.includes(q.toUpperCase()) || a.name.toLowerCase().includes(q.toLowerCase())))
      .slice(0, 10)
      .map(a => ({ symbol: a.symbol, name: a.name, exchange: a.exchange, fractionable: a.fractionable }));
    res.json(matches);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Transfer (ACH — Alpaca handles actual bank linking) ─────
app.get('/api/transfers', async (req, res) => {
  try {
    // Note: ACH relationships and transfers require Alpaca Broker API
    // For paper trading, this is informational only
    if (isPaper) {
      return res.json({
        note: 'Paper trading mode — deposits/withdrawals are simulated.',
        paperBalance: 'Alpaca paper accounts start with $100,000. Use the Alpaca dashboard to reset.',
      });
    }
    res.json({ message: 'Use Alpaca dashboard for ACH transfers: https://app.alpaca.markets' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── WebSocket: Stream live prices ───────────────────────────
const alpacaWsUrl = isPaper
  ? 'wss://stream.data.sandbox.alpaca.markets/v2/iex'
  : 'wss://stream.data.alpaca.markets/v2/iex';

let alpacaWs = null;
let subscribedSymbols = new Set();
const clients = new Set();

function connectAlpacaStream() {
  const WebSocket = (await import('ws')).default;

  alpacaWs = new WebSocket(alpacaWsUrl);

  alpacaWs.on('open', () => {
    console.log('🔌 Connected to Alpaca stream');
    alpacaWs.send(JSON.stringify({
      action: 'auth',
      key: process.env.ALPACA_API_KEY,
      secret: process.env.ALPACA_SECRET_KEY,
    }));
  });

  alpacaWs.on('message', (data) => {
    const messages = JSON.parse(data);
    for (const msg of messages) {
      if (msg.T === 'success' && msg.msg === 'authenticated') {
        console.log('✅ Alpaca stream authenticated');
        if (subscribedSymbols.size > 0) {
          alpacaWs.send(JSON.stringify({
            action: 'subscribe',
            trades: [...subscribedSymbols],
            quotes: [...subscribedSymbols],
          }));
        }
      }

      // Forward trade/quote data to all connected clients
      if (msg.T === 't' || msg.T === 'q') {
        const payload = JSON.stringify({
          type: msg.T === 't' ? 'trade' : 'quote',
          symbol: msg.S,
          price: msg.T === 't' ? msg.p : undefined,
          size: msg.T === 't' ? msg.s : undefined,
          bidPrice: msg.T === 'q' ? msg.bp : undefined,
          askPrice: msg.T === 'q' ? msg.ap : undefined,
          timestamp: msg.t,
        });
        for (const client of clients) {
          if (client.readyState === 1) client.send(payload);
        }
      }
    }
  });

  alpacaWs.on('close', () => {
    console.log('🔌 Alpaca stream disconnected, reconnecting in 5s...');
    setTimeout(connectAlpacaStream, 5000);
  });

  alpacaWs.on('error', (err) => {
    console.error('Alpaca stream error:', err.message);
  });
}

// Client WebSocket connections
wss.on('connection', (ws) => {
  clients.add(ws);
  console.log(`📡 Client connected (${clients.size} total)`);

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data);
      if (msg.action === 'subscribe' && msg.symbols) {
        const newSymbols = msg.symbols.filter(s => !subscribedSymbols.has(s));
        newSymbols.forEach(s => subscribedSymbols.add(s));

        if (newSymbols.length > 0 && alpacaWs?.readyState === 1) {
          alpacaWs.send(JSON.stringify({
            action: 'subscribe',
            trades: newSymbols,
            quotes: newSymbols,
          }));
        }
      }
    } catch (e) {}
  });

  ws.on('close', () => {
    clients.delete(ws);
    console.log(`📡 Client disconnected (${clients.size} total)`);
  });
});

// ── Serve static in production ──────────────────────────────
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(join(__dirname, '..', 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(join(__dirname, '..', 'dist', 'index.html'));
  });
}

// ── Start ───────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`
  ╔══════════════════════════════════════════════╗
  ║         μ MICROTRADE SERVER v1.0             ║
  ║──────────────────────────────────────────────║
  ║  Mode:   ${isPaper ? 'PAPER (sandbox)' : '🔴 LIVE TRADING'}${isPaper ? '     ' : ''}           ║
  ║  API:    http://localhost:${PORT}/api          ║
  ║  WS:     ws://localhost:${PORT}/ws             ║
  ╚══════════════════════════════════════════════╝
  `);

  // Connect to Alpaca stream for live data
  // connectAlpacaStream(); // Uncomment when you have valid API keys
});
