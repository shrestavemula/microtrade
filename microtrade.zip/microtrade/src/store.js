import { create } from 'zustand';

const API = '/api';

export const useStore = create((set, get) => ({
  // ── Connection State ────────────────────────
  connected: false,
  paper: true,
  marketOpen: false,
  loading: true,
  error: null,

  // ── Account ─────────────────────────────────
  account: null,
  positions: [],
  orders: [],

  // ── Market Data ─────────────────────────────
  selectedSymbol: 'AAPL',
  watchlist: ['AAPL', 'TSLA', 'NVDA', 'AMC', 'PLTR', 'SOFI'],
  snapshots: {},
  livePrices: {},
  bars: [],
  news: [],

  // ── UI State ────────────────────────────────
  activeTab: 'chart',
  sidebarTab: 'news',
  notification: null,

  // ── Actions ─────────────────────────────────
  setSelectedSymbol: (symbol) => set({ selectedSymbol: symbol }),
  setActiveTab: (tab) => set({ activeTab: tab }),
  setSidebarTab: (tab) => set({ sidebarTab: tab }),

  notify: (msg, type = 'success') => {
    set({ notification: { msg, type } });
    setTimeout(() => set({ notification: null }), 3500);
  },

  // ── API Actions ─────────────────────────────
  checkStatus: async () => {
    try {
      const res = await fetch(`${API}/status`);
      const data = await res.json();
      set({ connected: data.connected, paper: data.paper, marketOpen: data.marketOpen, loading: false });
    } catch (err) {
      set({ connected: false, loading: false, error: 'Cannot connect to server. Is it running?' });
    }
  },

  fetchAccount: async () => {
    try {
      const res = await fetch(`${API}/account`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      set({ account: data });
    } catch (err) {
      console.error('Account fetch error:', err);
    }
  },

  fetchPositions: async () => {
    try {
      const res = await fetch(`${API}/positions`);
      const data = await res.json();
      if (!Array.isArray(data)) throw new Error(data.error);
      set({ positions: data });
    } catch (err) {
      console.error('Positions fetch error:', err);
    }
  },

  fetchOrders: async () => {
    try {
      const res = await fetch(`${API}/orders`);
      const data = await res.json();
      if (!Array.isArray(data)) throw new Error(data.error);
      set({ orders: data });
    } catch (err) {
      console.error('Orders fetch error:', err);
    }
  },

  fetchSnapshots: async () => {
    const { watchlist } = get();
    try {
      const res = await fetch(`${API}/snapshots?symbols=${watchlist.join(',')}`);
      const data = await res.json();
      set({ snapshots: data });
    } catch (err) {
      console.error('Snapshots error:', err);
    }
  },

  fetchBars: async (symbol, timeframe = '1Min') => {
    try {
      const res = await fetch(`${API}/bars/${symbol}?timeframe=${timeframe}&limit=200`);
      const data = await res.json();
      if (Array.isArray(data)) set({ bars: data });
    } catch (err) {
      console.error('Bars error:', err);
    }
  },

  fetchNews: async (symbols = '') => {
    try {
      const res = await fetch(`${API}/news?symbols=${symbols}&limit=20`);
      const data = await res.json();
      if (Array.isArray(data)) set({ news: data });
    } catch (err) {
      console.error('News error:', err);
    }
  },

  placeOrder: async (orderParams) => {
    const { notify, fetchAccount, fetchPositions, fetchOrders } = get();
    try {
      const res = await fetch(`${API}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderParams),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      notify(`${orderParams.side.toUpperCase()} order placed for ${orderParams.symbol}`, 'success');

      // Refresh data
      setTimeout(() => {
        fetchAccount();
        fetchPositions();
        fetchOrders();
      }, 1000);

      return data;
    } catch (err) {
      notify(err.message, 'error');
      throw err;
    }
  },

  cancelOrder: async (orderId) => {
    const { notify, fetchOrders } = get();
    try {
      const res = await fetch(`${API}/orders/${orderId}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      notify('Order cancelled', 'success');
      fetchOrders();
    } catch (err) {
      notify(err.message, 'error');
    }
  },

  updateLivePrice: (symbol, price) => {
    set(state => ({
      livePrices: { ...state.livePrices, [symbol]: price },
    }));
  },

  addToWatchlist: (symbol) => {
    set(state => ({
      watchlist: state.watchlist.includes(symbol)
        ? state.watchlist
        : [...state.watchlist, symbol],
    }));
  },

  removeFromWatchlist: (symbol) => {
    set(state => ({
      watchlist: state.watchlist.filter(s => s !== symbol),
    }));
  },
}));
