import { useEffect, useRef } from 'react';
import { useStore } from '../store';

export function useWebSocket() {
  const wsRef = useRef(null);
  const updateLivePrice = useStore(s => s.updateLivePrice);
  const watchlist = useStore(s => s.watchlist);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    function connect() {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('🔌 WebSocket connected');
        ws.send(JSON.stringify({ action: 'subscribe', symbols: watchlist }));
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'trade' && data.price) {
            updateLivePrice(data.symbol, data.price);
          }
        } catch (e) {}
      };

      ws.onclose = () => {
        console.log('🔌 WebSocket disconnected, reconnecting...');
        setTimeout(connect, 3000);
      };

      ws.onerror = () => {};
    }

    connect();

    return () => {
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  // Subscribe to new symbols when watchlist changes
  useEffect(() => {
    if (wsRef.current?.readyState === 1) {
      wsRef.current.send(JSON.stringify({ action: 'subscribe', symbols: watchlist }));
    }
  }, [watchlist]);

  return wsRef;
}
