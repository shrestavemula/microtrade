import { useState } from 'react';
import { useStore } from '../store';

export default function TopBar() {
  const { account, paper } = useStore();
  const [showFund, setShowFund] = useState(false);

  return (
    <>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '6px 12px',
        background: 'linear-gradient(180deg, #1a1400 0%, #0d0d0d 100%)',
        borderBottom: '1px solid var(--border-bright)',
        flexShrink: 0,
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 22, height: 22, background: 'var(--amber)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 900, fontSize: 14, color: '#000',
          }}>μ</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 800, letterSpacing: 2, textTransform: 'uppercase' }}>MicroTrade</div>
            <div style={{ fontSize: 8, color: 'var(--text-dim)', letterSpacing: 1 }}>
              {paper ? 'PAPER TRADING' : 'LIVE TRADING'} • AI TERMINAL
            </div>
          </div>
        </div>

        {/* Account Info */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          {account && (
            <>
              <div style={{ textAlign: 'right' }}>
                <div className="stat-label">CASH</div>
                <div style={{ fontSize: 13, fontWeight: 700 }}>${account.cash.toFixed(2)}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="stat-label">EQUITY</div>
                <div style={{ fontSize: 13, fontWeight: 700 }}>${account.equity.toFixed(2)}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="stat-label">BUYING POWER</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--green)' }}>${account.buyingPower.toFixed(2)}</div>
              </div>
            </>
          )}
          <button
            className="btn-primary"
            onClick={() => setShowFund(true)}
            style={{ padding: '5px 12px' }}
          >± FUND</button>

          {paper && (
            <div style={{
              padding: '3px 8px', background: '#332200',
              fontSize: 8, fontWeight: 700, color: 'var(--amber)',
              letterSpacing: 1, border: '1px solid var(--border-bright)',
            }}>
              PAPER
            </div>
          )}
        </div>
      </div>

      {/* Fund Modal */}
      {showFund && (
        <div
          style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)',
            zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
          onClick={() => setShowFund(false)}
        >
          <div
            style={{
              background: 'var(--bg-tertiary)', border: '1px solid var(--amber)',
              padding: 24, width: 380, maxWidth: '90vw',
            }}
            onClick={e => e.stopPropagation()}
          >
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: 2, marginBottom: 16, textTransform: 'uppercase' }}>
              ± Fund Account
            </div>

            {paper ? (
              <div>
                <p style={{ color: 'var(--text-secondary)', fontSize: 11, lineHeight: 1.6, marginBottom: 12 }}>
                  You're in <strong style={{ color: 'var(--amber)' }}>paper trading mode</strong>. 
                  Alpaca paper accounts come with $100,000 of simulated funds.
                </p>
                <p style={{ color: 'var(--text-dim)', fontSize: 10, lineHeight: 1.5, marginBottom: 16 }}>
                  To add/withdraw real money, switch to live trading by setting <code style={{ color: 'var(--amber)' }}>ALPACA_PAPER=false</code> in 
                  your <code style={{ color: 'var(--amber)' }}>.env</code> file and using your live API keys.
                </p>
                <p style={{ color: 'var(--text-dim)', fontSize: 10, lineHeight: 1.5, marginBottom: 16 }}>
                  For live accounts, deposits and withdrawals are handled through ACH bank transfers 
                  via the Alpaca dashboard.
                </p>
                <a
                  href="https://app.alpaca.markets/paper/dashboard/overview"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                  style={{ display: 'block', textAlign: 'center', padding: '10px', textDecoration: 'none' }}
                >
                  OPEN ALPACA DASHBOARD →
                </a>
              </div>
            ) : (
              <div>
                <p style={{ color: 'var(--text-secondary)', fontSize: 11, lineHeight: 1.6, marginBottom: 16 }}>
                  Deposits and withdrawals are processed through <strong style={{ color: 'var(--amber)' }}>Alpaca's ACH transfer system</strong>. 
                  Link your bank account on the Alpaca dashboard to fund your account.
                </p>
                <a
                  href="https://app.alpaca.markets/dashboard/overview"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary"
                  style={{ display: 'block', textAlign: 'center', padding: '10px', textDecoration: 'none' }}
                >
                  MANAGE FUNDS ON ALPACA →
                </a>
              </div>
            )}

            <button
              className="btn-ghost"
              style={{ width: '100%', padding: '8px', marginTop: 10 }}
              onClick={() => setShowFund(false)}
            >CLOSE</button>
          </div>
        </div>
      )}
    </>
  );
}
