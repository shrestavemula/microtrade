import { useStore } from '../store';

export default function Notification() {
  const notification = useStore(s => s.notification);

  if (!notification) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 50,
      left: '50%',
      transform: 'translateX(-50%)',
      padding: '8px 24px',
      background: notification.type === 'error' ? 'var(--red)' : 'var(--green)',
      color: '#000',
      fontWeight: 700,
      fontSize: 11,
      zIndex: 999,
      letterSpacing: 0.5,
      boxShadow: '0 4px 24px rgba(0,0,0,0.6)',
      animation: 'fadeIn 0.2s ease',
    }}>
      {notification.msg}
    </div>
  );
}
