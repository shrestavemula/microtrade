import { useEffect, useState } from 'react';
import { useStore } from '../store';

export default function NewsFeed() {
  const { news, fetchNews, selectedSymbol, watchlist } = useStore();
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    const symbols = filter === 'all' ? '' : filter;
    fetchNews(symbols);
  }, [filter, selectedSymbol]);

  const filters = [
    { label: 'ALL', value: 'all' },
    { label: selectedSymbol, value: selectedSymbol },
  ];

  const timeAgo = (iso) => {
    if (!iso) return '';
    const diff = Date.now() - new Date(iso).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  };

  return (
    <div style={{
      width: 290, display: 'flex', flexDirection: 'column',
      overflow: 'hidden', background: '#080800', flexShrink: 0,
    }}>
      <div className="panel-title">
        <span>LIVE FEED</span>
        <div style={{ display: 'flex', gap: 2 }}>
          {filters.map(f => (
            <span
              key={f.value}
              onClick={() => setFilter(f.value)}
              style={{
                padding: '2px 6px', fontSize: 8, cursor: 'pointer', fontWeight: 600,
                letterSpacing: 0.5,
                background: filter === f.value ? 'var(--amber)' : 'transparent',
                color: filter === f.value ? '#000' : 'var(--text-dim)',
              }}
            >{f.label}</span>
          ))}
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto' }}>
        {news.length === 0 ? (
          <div style={{ padding: 20, textAlign: 'center', color: 'var(--text-dark)', fontSize: 10 }}>
            Loading news...
          </div>
        ) : (
          news.map((item, i) => (
            <a
              key={item.id || i}
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: 'block',
                padding: '10px 10px',
                borderBottom: '1px solid #111100',
                textDecoration: 'none',
                transition: 'background 0.15s',
              }}
              onMouseOver={e => e.currentTarget.style.background = '#111100'}
              onMouseOut={e => e.currentTarget.style.background = 'transparent'}
            >
              {/* Source & Time */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <span className="badge" style={{ background: 'var(--amber)', color: '#000' }}>
                  ART
                </span>
                <span style={{ fontSize: 9, color: 'var(--text-dim)', fontWeight: 600 }}>
                  {item.source}
                </span>
                <span style={{ fontSize: 8, color: 'var(--text-dark)', marginLeft: 'auto' }}>
                  {timeAgo(item.createdAt)}
                </span>
              </div>

              {/* Headline */}
              <div style={{ fontSize: 10, color: '#cca300', lineHeight: 1.45, marginBottom: 4 }}>
                {item.headline}
              </div>

              {/* Summary (truncated) */}
              {item.summary && (
                <div style={{
                  fontSize: 9, color: 'var(--text-dark)', lineHeight: 1.4,
                  maxHeight: 30, overflow: 'hidden', marginBottom: 4,
                }}>
                  {item.summary.slice(0, 120)}...
                </div>
              )}

              {/* Symbols */}
              {item.symbols && item.symbols.length > 0 && (
                <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
                  {item.symbols.map(sym => (
                    <span key={sym} style={{
                      fontSize: 8, padding: '1px 4px',
                      border: '1px solid var(--border-bright)',
                      color: sym === selectedSymbol ? 'var(--amber)' : 'var(--text-dim)',
                    }}>
                      {sym}
                    </span>
                  ))}
                </div>
              )}
            </a>
          ))
        )}
      </div>

      {/* Refresh button */}
      <div style={{
        padding: '6px 10px', borderTop: '1px solid var(--border)',
        background: 'var(--bg-secondary)', flexShrink: 0,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <span style={{ fontSize: 8, color: 'var(--text-dark)' }}>
          {news.length} articles loaded
        </span>
        <button
          className="btn-ghost"
          style={{ fontSize: 8, padding: '3px 8px' }}
          onClick={() => fetchNews(filter === 'all' ? '' : filter)}
        >
          REFRESH
        </button>
      </div>
    </div>
  );
}
