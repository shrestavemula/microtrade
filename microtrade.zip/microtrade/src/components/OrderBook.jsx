import { useStore } from '../store';

const STATUS_COLORS = {
  filled: 'var(--green)',
  partially_filled: 'var(--amber)',
  new: 'var(--blue)',
  accepted: 'var(--blue)',
  pending_new: 'var(--text-dim)',
  cancelled: 'var(--text-dark)',
  expired: 'var(--text-dark)',
  rejected: 'var(--red)',
  replaced: 'var(--amber)',
};

export default function OrderBook() {
  const { orders, cancelOrder } = useStore();

  const activeOrders = orders.filter(o => ['new', 'accepted', 'partially_filled', 'pending_new'].includes(o.status));
  const completedOrders = orders.filter(o => !['new', 'accepted', 'partially_filled', 'pending_new'].includes(o.status));

  const formatTime = (iso) => {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const OrderRow = ({ order, showCancel }) => (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '70px 50px 60px 70px 70px 90px 100px 60px',
      padding: '8px 10px',
      borderTop: '1px solid var(--border)',
      alignItems: 'center',
      fontSize: 10,
    }}>
      <span style={{ fontWeight: 700 }}>{order.symbol}</span>
      <span style={{
        fontWeight: 700,
        color: order.side === 'buy' ? 'var(--green)' : 'var(--red)',
        textTransform: 'uppercase',
      }}>{order.side}</span>
      <span>{order.qty || '—'}</span>
      <span>{order.type}</span>
      <span style={{ color: STATUS_COLORS[order.status] || 'var(--text-dim)' }}>
        {order.status}
      </span>
      <span>{order.filledAvgPrice ? `$${order.filledAvgPrice.toFixed(2)}` : '—'}</span>
      <span style={{ fontSize: 9, color: 'var(--text-dim)' }}>{formatTime(order.submittedAt)}</span>
      <span>
        {showCancel && (
          <button
            className="btn-ghost"
            style={{ fontSize: 8, padding: '2px 8px' }}
            onClick={() => cancelOrder(order.id)}
          >CANCEL</button>
        )}
      </span>
    </div>
  );

  const Header = () => (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '70px 50px 60px 70px 70px 90px 100px 60px',
      padding: '6px 10px',
      background: 'var(--amber-bg)',
      fontSize: 8, fontWeight: 700, letterSpacing: 1, color: 'var(--text-secondary)',
    }}>
      <span>SYMBOL</span>
      <span>SIDE</span>
      <span>QTY</span>
      <span>TYPE</span>
      <span>STATUS</span>
      <span>FILL PRICE</span>
      <span>TIME</span>
      <span></span>
    </div>
  );

  return (
    <div style={{ flex: 1, overflow: 'auto', padding: 12 }}>
      {/* Active Orders */}
      <div style={{ marginBottom: 16 }}>
        <div className="stat-label" style={{ marginBottom: 6 }}>
          ACTIVE ORDERS ({activeOrders.length})
        </div>
        <div style={{ border: '1px solid var(--border)' }}>
          <Header />
          {activeOrders.length === 0 ? (
            <div style={{ padding: 20, textAlign: 'center', color: 'var(--text-dark)', fontSize: 10 }}>
              No active orders
            </div>
          ) : activeOrders.map(o => <OrderRow key={o.id} order={o} showCancel={true} />)}
        </div>
      </div>

      {/* Order History */}
      <div>
        <div className="stat-label" style={{ marginBottom: 6 }}>
          ORDER HISTORY ({completedOrders.length})
        </div>
        <div style={{ border: '1px solid var(--border)' }}>
          <Header />
          {completedOrders.length === 0 ? (
            <div style={{ padding: 20, textAlign: 'center', color: 'var(--text-dark)', fontSize: 10 }}>
              No order history
            </div>
          ) : completedOrders.slice(0, 30).map(o => <OrderRow key={o.id} order={o} showCancel={false} />)}
        </div>
      </div>
    </div>
  );
}
