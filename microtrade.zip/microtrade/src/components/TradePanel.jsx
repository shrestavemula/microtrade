import { useState } from 'react';
import { useStore } from '../store';

export default function TradePanel() {
  const { selectedSymbol, account, snapshots, livePrices, placeOrder, positions } = useStore();
  const [side, setSide] = useState('buy');
  const [mode, setMode] = useState('dollars'); // 'dollars' or 'shares'
  const [amount, setAmount] = useState('');

  const price = livePrices[selectedSymbol] || snapshots[selectedSymbol]?.price || 0;
  const position = positions.find(p => p.symbol === selectedSymbol);
  const cash = account?.cash || 0;

  const estimatedShares = mode === 'dollars' && price > 0
    ? (parseFloat(amount || 0) / price)
    : parseFloat(amount || 0);

  const estimatedCost = mode === 'dollars'
    ? parseFloat(amount || 0)
    : parseFloat(amount || 0) * price;

  const handleTrade = async () => {
    if (!amount || parseFloat(amount) <= 0) return;

    // Safety cap
    if (estimatedCost > 100) {
      useStore.getState().notify('MicroTrade limits trades to $100', 'error');
      return;
    }

    const orderParams = {
      symbol: selectedSymbol,
      side,
      type: 'market',
      timeInForce: 'day',
    };

    if (mode === 'dollars') {
      orderParams.notional = parseFloat(amount).toFixed(2);
    } else {
      orderParams.qty = parseFloat(amount);
    }

    try {
      await placeOrder(orderParams);
      setAmount('');
    } catch (e) {}
  };

  const quickAmounts = [5, 10, 25, 50];

  return (
    <div style={{
      padding: '8px 10px',
      background: 'var(--bg-secondary)',
      borderTop: '1px solid var(--border-bright)',
      flexShrink: 0,
    }}>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
        {/* Buy/Sell toggle */}
        <div style={{ display: 'flex', border: '1px solid var(--border-bright)', overflow: 'hidden' }}>
          <div
            onClick={() => setSide('buy')}
            style={{
              padding: '5px 12px', cursor: 'pointer', fontSize: 9, fontWeight: 700, letterSpacing: 1,
              background: side === 'buy' ? 'var(--green)' : 'transparent',
              color: side === 'buy' ? '#000' : 'var(--text-dim)',
            }}
          >BUY</div>
          <div
            onClick={() => setSide('sell')}
            style={{
              padding: '5px 12px', cursor: 'pointer', fontSize: 9, fontWeight: 700, letterSpacing: 1,
              background: side === 'sell' ? 'var(--red)' : 'transparent',
              color: side === 'sell' ? '#000' : 'var(--text-dim)',
            }}
          >SELL</div>
        </div>

        {/* Symbol */}
        <span style={{ fontWeight: 700, fontSize: 11 }}>{selectedSymbol}</span>
        <span style={{ fontSize: 10, color: 'var(--text-secondary)' }}>
          @${price.toFixed(2)}
        </span>

        {/* Mode toggle */}
        <div style={{ display: 'flex', border: '1px solid var(--border)', overflow: 'hidden' }}>
          <div
            onClick={() => { setMode('dollars'); setAmount(''); }}
            style={{
              padding: '4px 8px', cursor: 'pointer', fontSize: 8, fontWeight: 600,
              background: mode === 'dollars' ? 'var(--amber-bg)' : 'transparent',
              color: mode === 'dollars' ? 'var(--amber)' : 'var(--text-dark)',
            }}
          >$$$</div>
          <div
            onClick={() => { setMode('shares'); setAmount(''); }}
            style={{
              padding: '4px 8px', cursor: 'pointer', fontSize: 8, fontWeight: 600,
              background: mode === 'shares' ? 'var(--amber-bg)' : 'transparent',
              color: mode === 'shares' ? 'var(--amber)' : 'var(--text-dark)',
            }}
          >SHARES</div>
        </div>

        {/* Amount input */}
        <div style={{ position: 'relative' }}>
          <input
            style={{ width: 100, paddingLeft: mode === 'dollars' ? 16 : 8 }}
            placeholder={mode === 'dollars' ? '0.00' : '0'}
            value={amount}
            onChange={e => setAmount(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleTrade()}
          />
          {mode === 'dollars' && (
            <span style={{
              position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)',
              color: 'var(--text-dim)', fontSize: 10,
            }}>$</span>
          )}
        </div>

        {/* Quick amounts */}
        {mode === 'dollars' && quickAmounts.map(v => (
          <button
            key={v}
            className="btn-ghost"
            style={{ padding: '4px 8px', fontSize: 8 }}
            onClick={() => setAmount(v.toString())}
          >${v}</button>
        ))}

        {/* Estimate */}
        <span style={{ fontSize: 9, color: 'var(--text-dim)' }}>
          {mode === 'dollars'
            ? `≈ ${estimatedShares.toFixed(4)} shares`
            : `≈ $${estimatedCost.toFixed(2)}`
          }
        </span>

        {/* Execute button */}
        <button
          className={side === 'buy' ? 'btn-buy' : 'btn-sell'}
          onClick={handleTrade}
          style={{ marginLeft: 'auto' }}
        >
          EXECUTE {side.toUpperCase()}
        </button>

        {/* Context info */}
        <span style={{ fontSize: 8, color: 'var(--text-dark)' }}>
          {side === 'buy'
            ? `Cash: $${cash.toFixed(2)}`
            : `Held: ${position ? position.qty : 0} shares`
          }
        </span>
      </div>

      {/* $100 limit notice */}
      {estimatedCost > 100 && (
        <div style={{
          marginTop: 4, fontSize: 9, color: 'var(--red)',
          padding: '3px 6px', background: 'rgba(255,82,82,0.1)',
        }}>
          ⚠ MicroTrade limits individual orders to $100
        </div>
      )}
    </div>
  );
}
