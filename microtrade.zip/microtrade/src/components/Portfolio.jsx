import { useStore } from '../store';

export default function Portfolio() {
  const { account, positions, livePrices, snapshots, setSelectedSymbol, setActiveTab } = useStore();

  const totalUnrealizedPL = positions.reduce((sum, p) => sum + p.unrealizedPL, 0);

  return (
    <div style={{ flex: 1, overflow: 'auto', padding: 12 }}>
      {/* Account Summary */}
      {account && (
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
          gap: 1, marginBottom: 16, background: 'var(--border)',
        }}>
          {[
            { label: 'Cash', value: `$${account.cash.toFixed(2)}`, color: 'var(--amber)' },
            { label: 'Portfolio Value', value: `$${account.portfolioValue.toFixed(2)}`, color: 'var(--amber)' },
            { label: 'Total Equity', value: `$${account.equity.toFixed(2)}`, color: 'var(--amber)' },
            { label: 'Buying Power', value: `$${account.buyingPower.toFixed(2)}`, color: 'var(--green)' },
            { label: 'Unrealized P&L', value: `${totalUnrealizedPL >= 0 ? '+' : ''}$${totalUnrealizedPL.toFixed(2)}`, color: totalUnrealizedPL >= 0 ? 'var(--green)' : 'var(--red)' },
            { label: 'Day Trades', value: `${account.daytradeCount}/3`, color: account.daytradeCount >= 3 ? 'var(--red)' : 'var(--amber)' },
          ].map((item, i) => (
            <div key={i} style={{ padding: '10px 12px', background: 'var(--bg-primary)' }}>
              <div className="stat-label">{item.label}</div>
              <div className="stat-value" style={{ color: item.color }}>{item.value}</div>
            </div>
          ))}
        </div>
      )}

      {/* Positions Table */}
      <div style={{ border: '1px solid var(--border)' }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: '80px 1fr 1fr 1fr 1fr 1fr 1fr',
          padding: '6px 10px',
          background: 'var(--amber-bg)',
          fontSize: 8, fontWeight: 700, letterSpacing: 1, color: 'var(--text-secondary)',
        }}>
          <span>SYMBOL</span>
          <span>QTY</span>
          <span>AVG ENTRY</span>
          <span>CURRENT</span>
          <span>MKT VALUE</span>
          <span>P&L</span>
          <span>P&L %</span>
        </div>

        {positions.length === 0 ? (
          <div style={{ padding: 30, textAlign: 'center', color: 'var(--text-dark)', fontSize: 10 }}>
            No open positions. Use the trade panel below to buy your first stock!
          </div>
        ) : (
          positions.map(pos => {
            const livePrice = livePrices[pos.symbol];
            const currentPrice = livePrice || pos.currentPrice;
            const pl = (currentPrice - pos.avgEntry) * pos.qty;
            const plPct = pos.avgEntry > 0 ? ((currentPrice - pos.avgEntry) / pos.avgEntry * 100) : 0;
            const isUp = pl >= 0;

            return (
              <div
                key={pos.symbol}
                onClick={() => { setSelectedSymbol(pos.symbol); setActiveTab('chart'); }}
                style={{
                  display: 'grid',
                  gridTemplateColumns: '80px 1fr 1fr 1fr 1fr 1fr 1fr',
                  padding: '10px',
                  borderTop: '1px solid var(--border)',
                  cursor: 'pointer',
                  alignItems: 'center',
                  transition: 'background 0.1s',
                }}
                onMouseOver={e => e.currentTarget.style.background = 'var(--amber-bg)'}
                onMouseOut={e => e.currentTarget.style.background = 'transparent'}
              >
                <span style={{ fontWeight: 700, fontSize: 11 }}>{pos.symbol}</span>
                <span>{pos.qty}</span>
                <span>${pos.avgEntry.toFixed(2)}</span>
                <span>${currentPrice.toFixed(2)}</span>
                <span>${pos.marketValue.toFixed(2)}</span>
                <span style={{ color: isUp ? 'var(--green)' : 'var(--red)', fontWeight: 600 }}>
                  {isUp ? '+' : ''}${pl.toFixed(2)}
                </span>
                <span style={{ color: isUp ? 'var(--green)' : 'var(--red)', fontWeight: 600 }}>
                  {isUp ? '+' : ''}{plPct.toFixed(2)}%
                </span>
              </div>
            );
          })
        )}
      </div>

      {/* Disclaimer */}
      <div style={{
        marginTop: 16, padding: 10,
        border: '1px solid var(--border)',
        fontSize: 8, color: 'var(--text-dark)', lineHeight: 1.5,
      }}>
        ⚠ MicroTrade is designed for small trades under $100. This is not financial advice.
        All trades are executed through Alpaca Securities LLC. Past performance does not guarantee future results.
        {account?.patternDayTrader && (
          <span style={{ color: 'var(--red)', display: 'block', marginTop: 4 }}>
            ⚠ PATTERN DAY TRADER flagged. You are limited to 3 day trades per 5 business days.
          </span>
        )}
      </div>
    </div>
  );
}
