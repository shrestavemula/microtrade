export default function SetupScreen({ error }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      height: '100vh', padding: 20,
    }}>
      <div style={{
        maxWidth: 560, width: '100%',
        border: '1px solid var(--amber)',
        background: 'var(--bg-tertiary)',
      }}>
        {/* Header */}
        <div style={{
          padding: '20px 24px',
          borderBottom: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 36, height: 36, background: 'var(--amber)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 900, fontSize: 22, color: '#000',
          }}>μ</div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: 3, textTransform: 'uppercase' }}>
              MicroTrade
            </div>
            <div style={{ fontSize: 9, color: 'var(--text-dim)', letterSpacing: 1 }}>
              AI TRADING TERMINAL • SETUP
            </div>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div style={{
            padding: '10px 24px', background: 'rgba(255,82,82,0.1)',
            borderBottom: '1px solid rgba(255,82,82,0.2)',
            fontSize: 10, color: 'var(--red)',
          }}>
            ⚠ {error}
          </div>
        )}

        {/* Steps */}
        <div style={{ padding: '20px 24px' }}>
          <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginBottom: 20, lineHeight: 1.6 }}>
            MicroTrade needs to connect to the backend server and your Alpaca brokerage account.
            Follow these steps to get started:
          </div>

          {/* Step 1 */}
          <Step num={1} title="Sign up for Alpaca">
            <span>Create a free account at </span>
            <a href="https://alpaca.markets" target="_blank" rel="noopener noreferrer">alpaca.markets</a>
            <span>. Alpaca provides commission-free trading with fractional shares — perfect for small trades under $100.</span>
          </Step>

          {/* Step 2 */}
          <Step num={2} title="Get your API keys">
            <span>Go to your </span>
            <a href="https://app.alpaca.markets/paper/dashboard/overview" target="_blank" rel="noopener noreferrer">
              Alpaca Paper Trading Dashboard
            </a>
            <span> → API Keys → Generate New Key. Copy both the <Code>API Key</Code> and <Code>Secret Key</Code>.</span>
          </Step>

          {/* Step 3 */}
          <Step num={3} title="Configure environment">
            <span>Copy <Code>.env.example</Code> to <Code>.env</Code> and paste your keys:</span>
            <pre style={{
              background: '#000', padding: 12, marginTop: 8,
              fontSize: 10, lineHeight: 1.6, overflow: 'auto',
              border: '1px solid var(--border)',
            }}>
{`ALPACA_API_KEY=PK...your_key
ALPACA_SECRET_KEY=...your_secret
ALPACA_PAPER=true`}
            </pre>
          </Step>

          {/* Step 4 */}
          <Step num={4} title="Start the server">
            <pre style={{
              background: '#000', padding: 12, marginTop: 4,
              fontSize: 10, lineHeight: 1.6,
              border: '1px solid var(--border)',
            }}>
{`npm install
npm run dev`}
            </pre>
            <span style={{ fontSize: 9, color: 'var(--text-dark)', display: 'block', marginTop: 6 }}>
              This starts both the Express API server (port 3001) and the Vite dev server (port 5173).
            </span>
          </Step>

          {/* Step 5 */}
          <Step num={5} title="Go live (when ready)">
            <span>
              When you're confident with paper trading, switch to live by changing
              <Code>ALPACA_PAPER=false</Code> and using your live API keys from the
              Alpaca dashboard. Link your bank account on Alpaca for deposits/withdrawals.
            </span>
          </Step>

          {/* Retry */}
          <button
            className="btn-primary"
            style={{ width: '100%', padding: 12, marginTop: 20, fontSize: 11 }}
            onClick={() => window.location.reload()}
          >
            RETRY CONNECTION
          </button>
        </div>

        {/* Footer */}
        <div style={{
          padding: '10px 24px',
          borderTop: '1px solid var(--border)',
          fontSize: 8, color: 'var(--text-dark)', lineHeight: 1.5,
        }}>
          MicroTrade is open-source software. Trades are executed through Alpaca Securities LLC, 
          member FINRA/SIPC. This is not financial advice. Start with paper trading.
        </div>
      </div>
    </div>
  );
}

function Step({ num, title, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <div style={{
          width: 20, height: 20,
          background: 'var(--amber)', color: '#000',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 800, fontSize: 10, flexShrink: 0,
        }}>{num}</div>
        <div style={{ fontWeight: 700, fontSize: 11, letterSpacing: 0.5 }}>{title}</div>
      </div>
      <div style={{ marginLeft: 28, fontSize: 10, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
        {children}
      </div>
    </div>
  );
}

function Code({ children }) {
  return (
    <code style={{
      background: '#000', padding: '1px 5px',
      color: 'var(--amber)', fontSize: 10,
      border: '1px solid var(--border)',
    }}>{children}</code>
  );
}
