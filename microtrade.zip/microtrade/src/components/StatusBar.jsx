import { useState, useEffect } from 'react';
import { useStore } from '../store';

export default function StatusBar() {
  const { connected, paper, marketOpen } = useStore();
  const [clock, setClock] = useState(new Date());

  useEffect(() => {
    const iv = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '4px 12px',
      background: 'var(--bg-secondary)',
      borderTop: '1px solid var(--border-bright)',
      fontSize: 9, color: 'var(--text-dim)',
      flexShrink: 0,
    }}>
      <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
        <span>
          MKT: <span style={{ color: marketOpen ? 'var(--green)' : 'var(--red)' }}>
            {marketOpen ? 'OPEN' : 'CLOSED'}
          </span>
        </span>
        <span>NYSE {clock.toLocaleTimeString('en-US', { hour12: false })}</span>
        <span>
          {connected
            ? <><span className="animate-pulse" style={{ color: 'var(--green)' }}>●</span> CONNECTED</>
            : <><span style={{ color: 'var(--red)' }}>●</span> DISCONNECTED</>
          }
        </span>
      </div>
      <div style={{ display: 'flex', gap: 14 }}>
        <span>MODE: {paper ? 'PAPER' : 'LIVE'}</span>
        <span>BROKER: ALPACA</span>
        <span>v1.0.0</span>
      </div>
    </div>
  );
}
