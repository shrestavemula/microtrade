import { useState } from 'react';
import { useStore } from '../store';

export default function Watchlist() {
  const { watchlist, selectedSymbol, setSelectedSymbol, snapshots, livePrices, addToWatchlist, removeFromWatchlist } = useStore();
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);

  const handleSearch = async (q) => {
    setSearch(q);
    if (q.length < 1) { setSearchResults([]); return; }
    setSearching(true);
    try {
      const res = await fetch(`/api/assets/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      setSearchResults(Array.isArray(data) ? data : []);
    } catch (e) {
      setSearchResults([]);
    }
    setSearching(false);
  };

  return (
    <div style={{
      width: 180, borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
      background: 'var(--bg-secondary)', flexShrink: 0,
    }}>
      <div className="panel-title" style={{ fontSize: 9 }}>
        <span>WATCHLIST</span>
        <span style={{ fontSize: 8, color: 'var(--text-dim)' }}>{watchlist.length}</span>
      </div>

      {/* Search */}
      <div style={{ padding: '6px 8px', borderBottom: '1px solid var(--border)' }}>
        <input
          style={{ width: '100%', fontSize: 10, padding: '5px 6px' }}
          placeholder="+ Add symbol..."
          value={search}
          onChange={e => handleSearch(e.target.value)}
        />
        {searchResults.length > 0 && (
          <div style={{
            position: 'relative', zIndex: 20,
          }}>
            <div style={{
              position: 'absolute', top: 2, left: 0, right: 0,
              background: 'var(--bg-tertiary)', border: '1px solid var(--border-bright)',
              maxHeight: 200, overflow: 'auto',
            }}>
              {searchResults.map(r => (
                <div
                  key={r.symbol}
                  style={{
                    padding: '6px 8px', cursor: 'pointer',
                    borderBottom: '1px solid var(--border)',
                    fontSize: 10,
                  }}
                  onClick={() => {
                    addToWatchlist(r.symbol);
                    setSelectedSymbol(r.symbol);
                    setSearch('');
                    setSearchResults([]);
                  }}
                  onMouseOver={e => e.currentTarget.style.background = 'var(--amber-bg)'}
                  onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                >
                  <div style={{ fontWeight: 700 }}>{r.symbol}</div>
                  <div style={{ fontSize: 8, color: 'var(--text-dim)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {r.name}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Stock List */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        {watchlist.map(symbol => {
          const snap = snapshots[symbol];
          const livePrice = livePrices[symbol];
          const price = livePrice || snap?.price || 0;
          const prevClose = snap?.prevClose || price;
          const change = price - prevClose;
          const changePct = prevClose ? (change / prevClose) * 100 : 0;
          const isUp = change >= 0;
          const isSelected = symbol === selectedSymbol;

          return (
            <div
              key={symbol}
              onClick={() => setSelectedSymbol(symbol)}
              style={{
                padding: '8px 10px',
                cursor: 'pointer',
                borderBottom: '1px solid var(--border)',
                background: isSelected ? 'var(--amber-bg)' : 'transparent',
                borderLeft: isSelected ? '2px solid var(--amber)' : '2px solid transparent',
                transition: 'all 0.1s',
              }}
              onMouseOver={e => { if (!isSelected) e.currentTarget.style.background = '#0f0f04'; }}
              onMouseOut={e => { if (!isSelected) e.currentTarget.style.background = 'transparent'; }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: 700, fontSize: 11 }}>{symbol}</span>
                <span
                  style={{ fontSize: 8, cursor: 'pointer', color: 'var(--text-dark)', padding: '0 2px' }}
                  onClick={(e) => { e.stopPropagation(); removeFromWatchlist(symbol); }}
                  title="Remove"
                >✕</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 3 }}>
                <span style={{ fontSize: 11, fontWeight: 600 }}>
                  {price > 0 ? `$${price.toFixed(2)}` : '—'}
                </span>
                <span style={{ fontSize: 9, color: isUp ? 'var(--green)' : 'var(--red)', fontWeight: 600 }}>
                  {change !== 0 ? `${isUp ? '+' : ''}${changePct.toFixed(2)}%` : '—'}
                </span>
              </div>
              {livePrice && (
                <div style={{ fontSize: 7, color: 'var(--text-dark)', marginTop: 2 }}>
                  <span className="animate-pulse">●</span> LIVE
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
