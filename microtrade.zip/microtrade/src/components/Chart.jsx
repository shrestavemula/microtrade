import { useEffect, useRef, useState } from 'react';
import { useStore } from '../store';

const TIMEFRAMES = [
  { label: '1m', value: '1Min' },
  { label: '5m', value: '5Min' },
  { label: '15m', value: '15Min' },
  { label: '1H', value: '1Hour' },
  { label: '1D', value: '1Day' },
];

export default function Chart() {
  const { selectedSymbol, bars, fetchBars, snapshots, livePrices } = useStore();
  const [timeframe, setTimeframe] = useState('5Min');
  const [hovered, setHovered] = useState(null);
  const canvasRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    fetchBars(selectedSymbol, timeframe);
    const iv = setInterval(() => fetchBars(selectedSymbol, timeframe), 30000);
    return () => clearInterval(iv);
  }, [selectedSymbol, timeframe]);

  const snap = snapshots[selectedSymbol];
  const livePrice = livePrices[selectedSymbol];
  const currentPrice = livePrice || snap?.price || 0;

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container || bars.length === 0) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = container.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    const w = rect.width;
    const h = rect.height;
    const padL = 60, padR = 12, padT = 40, padB = 30;
    const cw = w - padL - padR;
    const ch = h - padT - padB;

    const closes = bars.map(b => b.close);
    const vols = bars.map(b => b.volume);
    const min = Math.min(...closes) * 0.998;
    const max = Math.max(...closes) * 1.002;
    const range = max - min || 1;
    const maxVol = Math.max(...vols) || 1;

    ctx.clearRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = 'rgba(255,176,0,0.06)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 6; i++) {
      const y = padT + (ch / 6) * i;
      ctx.beginPath();
      ctx.moveTo(padL, y);
      ctx.lineTo(w - padR, y);
      ctx.stroke();

      ctx.fillStyle = 'rgba(255,176,0,0.35)';
      ctx.font = '9px IBM Plex Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText((max - (range / 6) * i).toFixed(2), padL - 6, y + 3);
    }

    // Volume bars
    bars.forEach((b, i) => {
      const x = padL + (i / (bars.length - 1)) * cw;
      const bh = (b.volume / maxVol) * (ch * 0.12);
      const isUp = b.close >= b.open;
      ctx.fillStyle = isUp ? 'rgba(0,230,118,0.12)' : 'rgba(255,82,82,0.12)';
      ctx.fillRect(x - 1.5, padT + ch - bh, 3, bh);
    });

    // Candlestick bars or line
    if (timeframe === '1Day' || timeframe === '1Hour') {
      // Candlesticks
      const barWidth = Math.max(2, (cw / bars.length) * 0.6);
      bars.forEach((b, i) => {
        const x = padL + (i / (bars.length - 1)) * cw;
        const isUp = b.close >= b.open;
        const color = isUp ? '#00e676' : '#ff5252';

        // Wick
        const highY = padT + ch - ((b.high - min) / range) * ch;
        const lowY = padT + ch - ((b.low - min) / range) * ch;
        ctx.strokeStyle = color;
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.moveTo(x, highY);
        ctx.lineTo(x, lowY);
        ctx.stroke();

        // Body
        const openY = padT + ch - ((b.open - min) / range) * ch;
        const closeY = padT + ch - ((b.close - min) / range) * ch;
        ctx.fillStyle = isUp ? color : color;
        ctx.fillRect(x - barWidth / 2, Math.min(openY, closeY), barWidth, Math.abs(closeY - openY) || 1);
      });
    } else {
      // Line chart
      const isUp = closes[closes.length - 1] >= closes[0];
      const lineColor = isUp ? '#00e676' : '#ff5252';

      ctx.beginPath();
      bars.forEach((b, i) => {
        const x = padL + (i / (bars.length - 1)) * cw;
        const y = padT + ch - ((b.close - min) / range) * ch;
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      });
      ctx.strokeStyle = lineColor;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Fill gradient
      const lastX = padL + cw;
      ctx.lineTo(lastX, padT + ch);
      ctx.lineTo(padL, padT + ch);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, padT, 0, padT + ch);
      grad.addColorStop(0, isUp ? 'rgba(0,230,118,0.1)' : 'rgba(255,82,82,0.1)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grad;
      ctx.fill();
    }

    // Current price dashed line
    if (currentPrice > 0) {
      const priceY = padT + ch - ((currentPrice - min) / range) * ch;
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = 'rgba(255,176,0,0.4)';
      ctx.lineWidth = 0.7;
      ctx.beginPath();
      ctx.moveTo(padL, priceY);
      ctx.lineTo(w - padR, priceY);
      ctx.stroke();
      ctx.setLineDash([]);

      // Price label
      ctx.fillStyle = 'var(--amber)';
      ctx.fillRect(w - padR - 1, priceY - 8, padR + 1, 16);
      ctx.fillStyle = '#000';
      ctx.font = 'bold 8px IBM Plex Mono, monospace';
      ctx.textAlign = 'left';
      // Just show the dashed line without overlapping text
    }

    // Hover crosshair
    if (hovered !== null && hovered >= 0 && hovered < bars.length) {
      const b = bars[hovered];
      const x = padL + (hovered / (bars.length - 1)) * cw;
      const y = padT + ch - ((b.close - min) / range) * ch;

      // Vertical line
      ctx.setLineDash([2, 2]);
      ctx.strokeStyle = 'rgba(255,176,0,0.25)';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(x, padT);
      ctx.lineTo(x, padT + ch);
      ctx.stroke();
      ctx.setLineDash([]);

      // Dot
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = b.close >= b.open ? '#00e676' : '#ff5252';
      ctx.fill();
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Tooltip
      const tooltipW = 120;
      const tooltipH = 52;
      const tx = Math.min(x + 10, w - tooltipW - 10);
      const ty = Math.max(y - tooltipH - 10, padT);

      ctx.fillStyle = 'rgba(0,0,0,0.9)';
      ctx.fillRect(tx, ty, tooltipW, tooltipH);
      ctx.strokeStyle = 'rgba(255,176,0,0.3)';
      ctx.lineWidth = 0.5;
      ctx.strokeRect(tx, ty, tooltipW, tooltipH);

      ctx.fillStyle = '#FFB000';
      ctx.font = 'bold 10px IBM Plex Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`$${b.close.toFixed(2)}`, tx + 6, ty + 14);

      ctx.font = '8px IBM Plex Mono, monospace';
      ctx.fillStyle = '#998800';
      ctx.fillText(`O: ${b.open.toFixed(2)} H: ${b.high.toFixed(2)}`, tx + 6, ty + 28);
      ctx.fillText(`L: ${b.low.toFixed(2)} V: ${(b.volume / 1000).toFixed(0)}K`, tx + 6, ty + 40);
    }

    // Header info
    ctx.fillStyle = '#FFB000';
    ctx.font = 'bold 13px IBM Plex Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText(selectedSymbol, padL, 20);

    ctx.font = '10px IBM Plex Mono, monospace';
    ctx.fillStyle = '#888';
    ctx.fillText(`${TIMEFRAMES.find(t => t.value === timeframe)?.label || ''} Chart`, padL + 60, 20);

    if (currentPrice > 0) {
      const prevClose = snap?.prevClose || closes[0];
      const ch2 = currentPrice - prevClose;
      const pct = prevClose ? (ch2 / prevClose * 100) : 0;
      ctx.fillStyle = ch2 >= 0 ? '#00e676' : '#ff5252';
      ctx.font = 'bold 11px IBM Plex Mono, monospace';
      ctx.fillText(`$${currentPrice.toFixed(2)} ${ch2 >= 0 ? '+' : ''}${ch2.toFixed(2)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%)`, padL + 140, 20);
    }

  }, [bars, hovered, currentPrice, selectedSymbol, timeframe, snapshots]);

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const idx = Math.round(x * (bars.length - 1));
    setHovered(Math.max(0, Math.min(bars.length - 1, idx)));
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Timeframe selector */}
      <div style={{
        display: 'flex', gap: 2, padding: '4px 8px',
        borderBottom: '1px solid var(--border)', background: 'var(--bg-secondary)',
      }}>
        {TIMEFRAMES.map(tf => (
          <div
            key={tf.value}
            onClick={() => setTimeframe(tf.value)}
            style={{
              padding: '3px 10px', cursor: 'pointer', fontSize: 9, fontWeight: 600,
              background: timeframe === tf.value ? 'var(--amber)' : 'transparent',
              color: timeframe === tf.value ? '#000' : 'var(--text-dim)',
              letterSpacing: 0.5,
            }}
          >
            {tf.label}
          </div>
        ))}
      </div>

      {/* Canvas */}
      <div ref={containerRef} style={{ flex: 1, position: 'relative', background: '#050505' }}>
        {bars.length === 0 ? (
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            height: '100%', color: 'var(--text-dim)', fontSize: 10,
          }}>
            {`Loading ${selectedSymbol} data...`}
          </div>
        ) : (
          <canvas
            ref={canvasRef}
            onMouseMove={handleMouseMove}
            onMouseLeave={() => setHovered(null)}
            style={{ width: '100%', height: '100%', cursor: 'crosshair', display: 'block' }}
          />
        )}
      </div>
    </div>
  );
}
