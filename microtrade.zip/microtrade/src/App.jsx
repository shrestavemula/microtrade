import { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { useStore } from './store';
import { useWebSocket } from './hooks/useWebSocket';
import TopBar from './components/TopBar';
import Watchlist from './components/Watchlist';
import Chart from './components/Chart';
import TradePanel from './components/TradePanel';
import Portfolio from './components/Portfolio';
import OrderBook from './components/OrderBook';
import NewsFeed from './components/NewsFeed';
import StatusBar from './components/StatusBar';
import SetupScreen from './components/SetupScreen';
import Notification from './components/Notification';

export default function App() {
  const { connected, loading, error, checkStatus, fetchAccount, fetchPositions, fetchOrders, fetchSnapshots, fetchNews, activeTab } = useStore();

  useWebSocket();

  useEffect(() => {
    checkStatus();
  }, []);

  useEffect(() => {
    if (connected) {
      fetchAccount();
      fetchPositions();
      fetchOrders();
      fetchSnapshots();
      fetchNews();

      // Poll for updates
      const interval = setInterval(() => {
        fetchAccount();
        fetchPositions();
        fetchSnapshots();
      }, 10000);

      const newsInterval = setInterval(() => {
        fetchNews();
      }, 60000);

      return () => {
        clearInterval(interval);
        clearInterval(newsInterval);
      };
    }
  }, [connected]);

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', flexDirection: 'column', gap: 12 }}>
        <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: 3 }}>μ</div>
        <div style={{ fontSize: 10, color: 'var(--text-dim)', letterSpacing: 2 }}>CONNECTING...</div>
      </div>
    );
  }

  if (!connected) {
    return <SetupScreen error={error} />;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
      <Notification />
      <TopBar />

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Left: Watchlist */}
        <Watchlist />

        {/* Center: Main content */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', borderRight: '1px solid var(--border)' }}>
          {/* Tabs */}
          <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
            {['chart', 'portfolio', 'orders'].map(tab => (
              <div
                key={tab}
                onClick={() => useStore.getState().setActiveTab(tab)}
                style={{
                  padding: '7px 16px',
                  cursor: 'pointer',
                  fontSize: 9,
                  fontWeight: 700,
                  letterSpacing: 1.5,
                  textTransform: 'uppercase',
                  color: activeTab === tab ? 'var(--amber)' : 'var(--text-dark)',
                  borderBottom: activeTab === tab ? '2px solid var(--amber)' : '2px solid transparent',
                  transition: 'all 0.15s',
                }}
              >
                {tab}
              </div>
            ))}
          </div>

          {/* Tab Content */}
          <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            {activeTab === 'chart' && <Chart />}
            {activeTab === 'portfolio' && <Portfolio />}
            {activeTab === 'orders' && <OrderBook />}
          </div>

          {/* Trade Panel */}
          <TradePanel />
        </div>

        {/* Right: News Sidebar */}
        <NewsFeed />
      </div>

      <StatusBar />
    </div>
  );
}
